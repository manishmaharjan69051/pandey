<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
$app->get('/index','AuthController:index')->setName('home');
$app->get('/loginPage','AuthController:loginPage')->setName('loginPage');
$app->get('/hotOffer/{id}','AuthController:hotOffer');
$app->get('/bannerPage/{id}','AuthController:bannerPage');
$app->get('/productPage/{name}/{id}','AuthController:SingleProductPage');
$app->get('/categoryPage/{id}','AuthController:categoryPage');

$app->get('/specialOffer','AuthController:specialOffer');
$app->get('/aboutUs','AuthController:aboutUs');

$app->get('/event','AuthController:event');
$app->get('/services','AuthController:services');


$app->get('/faq','AuthController:faq');

$app->get('/contact','AuthController:contact')->setName('contact');


$app->post('/contactForm','AuthController:contactForm');


$app->post('/login','AuthController:loginPost');
$app->post('/signUp','AuthController:signUpPost');


$app->post('/checkout','AuthController:checkout');

$app->get('/logOut','AuthController:getSignOut')->setName('logOut');	




$app->group('/admin',function(){
$this->get('/adminpage','AuthController:index1')->setName('home1');

$this->get('/newCategory','AuthController:addNewCategory')->setName('addNewCategory');
$this->get('/newProduct','AuthController:addNewProduct')->setName('addNewProduct');

$this->get('/allCategory','AuthController:allCategory')->setName('categoryList');


$this->get('/allProducts','AuthController:allProducts')->setName('productList');

$this->get('/userlist','AuthController:userlist')->setName('userPage');	


$this->post('/addCategoryPost','AuthController:addCategoryPost');
$this->post('/addProductPost','AuthController:addProductPost');

$this->post('/editCategoryPost','AuthController:editCategoryPost');
$this->post('/editProductPost','AuthController:editProductPost');

$this->post('/editCategory','AuthController:editCategory');
$this->post('/editProduct','AuthController:editProduct');

$this->post('/deleteCategory','AuthController:deleteCategory');
$this->post('/deleteProduct','AuthController:deleteProduct');



$this->get('/auth/signout','AuthController:getSignOut')->setName('auth.signout');	
})->add(new AuthMiddleware($container));

$app->group('/user',function(){
	$this->get('','AuthController:index1')->setName('home1');

	$this->get('/auth/signout','AuthController:getSignOut')->setName('auth.signout');
	
	
})->add(new AuthMiddleware($container));



